import kotlin.math.*

fun fitnessFunktion2(netz : Netzwerk):Double {

    var zeit = 0.0
    val zeitschritt= 0.01
    val g= 9.81
    var wagenX =0.0
    var wagenV =0.0
    var wagenA= 0.0
    val wagenMasse= 1

    var stabRotation= 0.0174532925199433
    var stabWinkelgeschwindigkeit=0.0
    var stabWinkelbeschleunigung = 0.0
    val stabMasse= 0.1
    var stabHalbeLaenge= 0.5
    var stabEffektiveMasse= stabMasse*(1-(3/4)*cos(stabRotation).pow(2))
    var stabEffektiveKraft=0.0
    var stabReibung = 0.000002


    var stab2Rotation= 0.0
    var stab2Winkelgeschwindigkeit=0.0
    var stab2Winkelbeschleunigung = 0.0
    val stab2Masse= 0.01
    var stab2HalbeLaenge= 0.05
    var  stab2EffektiveMasse= stab2Masse*(1-(3/4)*cos(stab2Rotation).pow(2))
    var stab2EffektiveKraft=0.0
    var stab2Reibung= 0.000002


    val streckenGrenze = 2.4
    val drehGrenze = 0.62831853
    val kraft = 10.0

    var reibungscoeffizient= 0.0005



    var aBewegungen=0
    while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && stab2Rotation<drehGrenze && stab2Rotation>-drehGrenze&& aBewegungen<100000){

        var angewendeteKraft:Double
        var output= netz.rechnen(doubleArrayOf(wagenX,wagenV,stabRotation,stabWinkelgeschwindigkeit,stab2Rotation,stab2Winkelgeschwindigkeit))

        if (output[0]==0.0)   angewendeteKraft= kraft
        else                      angewendeteKraft= -kraft


        stabWinkelbeschleunigung= -(3/(4*stabHalbeLaenge))*(wagenA* cos(stabRotation)+ g* sin(stabRotation)+(stabReibung*stabWinkelgeschwindigkeit)/stabMasse*stabHalbeLaenge)

        stab2Winkelbeschleunigung= -(3/(4*stab2HalbeLaenge))*(wagenA* cos(stab2Rotation)+ g* sin(stab2Rotation)+(stab2Reibung*stab2Winkelgeschwindigkeit)/stab2Masse*stab2HalbeLaenge)

        wagenA= (angewendeteKraft-reibungscoeffizient*sign(wagenV)+(stabEffektiveKraft+stab2EffektiveKraft))/(wagenMasse+(stab2EffektiveMasse+stabEffektiveMasse))

        stabEffektiveKraft= stabMasse*stabHalbeLaenge*stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation)+ (3/4)*stabMasse*cos(stabRotation)*((stabReibung*stabWinkelgeschwindigkeit)/(stabMasse*stabHalbeLaenge)+g*sin(stabRotation))

        stab2EffektiveKraft= stab2Masse*stab2HalbeLaenge*stab2Winkelgeschwindigkeit.pow(2)*sin(stab2Rotation)+ (3/4)*stab2Masse*cos(stab2Rotation)*((stab2Reibung*stab2Winkelgeschwindigkeit)/(stab2Masse*stab2HalbeLaenge)+g*sin(stab2Rotation))

        stabEffektiveMasse= stabMasse*(1-(3/4)*cos(stabRotation).pow(2))
        stab2EffektiveMasse= stab2Masse*(1-(3/4)*cos(stab2Rotation).pow(2))

        wagenX += zeitschritt*wagenV
        wagenV += zeitschritt*wagenA

        stabRotation+= zeitschritt*stabWinkelgeschwindigkeit
        stabWinkelgeschwindigkeit += zeitschritt*stabWinkelbeschleunigung

        stab2Rotation+= zeitschritt*stab2Winkelgeschwindigkeit
        stab2Winkelgeschwindigkeit += zeitschritt*stab2Winkelbeschleunigung

        aBewegungen++
        zeit+= zeitschritt

        if (wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && stab2Rotation<drehGrenze && stab2Rotation>-drehGrenze&& aBewegungen<100000){

        wagenX += zeitschritt*wagenV

        stabRotation+= zeitschritt*stabWinkelgeschwindigkeit
        stab2Rotation+= zeitschritt*stab2Winkelgeschwindigkeit

        zeit+= zeitschritt
    }}
    netz.fitness= aBewegungen.toDouble()

    return aBewegungen.toDouble()

}

