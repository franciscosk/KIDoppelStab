
import com.soywiz.klock.TimeSpan
import com.soywiz.korag.shader.Program
import com.soywiz.korev.Key
import com.soywiz.korev.MouseEvent
import com.soywiz.korge.Korge
import com.soywiz.korge.box2d.body
import com.soywiz.korge.box2d.nearestBox2dWorld
import com.soywiz.korge.box2d.registerBody
import com.soywiz.korge.box2d.registerBodyWithFixture
import com.soywiz.korge.time.delay
import com.soywiz.korge.view.*
import com.soywiz.korim.color.Colors
import com.soywiz.korim.text.TextAlignment
import com.soywiz.korio.async.delay
import com.soywiz.korma.geom.Angle
import com.soywiz.korma.geom.degrees
import kotlinx.coroutines.isActive
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.BodyDef
import org.jbox2d.dynamics.BodyType
import org.jbox2d.dynamics.joints.*
import org.jbox2d.pooling.IWorldPool
import org.jbox2d.pooling.normal.DefaultWorldPool
import kotlin.math.*

suspend fun fitness2Visuell(netz: Netzwerk,generation: Int = 1, genom: Int = 1)  =  Korge(width = 1920, height = 1080, bgcolor = Colors["#2b2b2b"]){

    macheNetzMagie2(netz, this,generation,genom);


}

suspend fun macheNetzMagie2(netz : Netzwerk, stage: Stage, generation: Int, genom: Int) {


    var zeit = 0.0
    val zeitschritt= 0.01
    val g= 9.81
    var wagenX =0.0
    var wagenV =0.0
    var wagenA= 0.0
    val wagenMasse= 1

    var stabRotation= 0.0174532925199433
    var stabWinkelgeschwindigkeit=0.0
    var stabWinkelbeschleunigung = 0.0
    val stabMasse= 0.1
    var stabHalbeLaenge= 0.5
    var stabEffektiveMasse= stabMasse*(1-(3/4)*cos(stabRotation).pow(2))
    var stabEffektiveKraft=0.0
    var stabReibung = 0.0


    var stab2Rotation= 0.0
    var stab2Winkelgeschwindigkeit=0.0
    var stab2Winkelbeschleunigung = 0.0
    val stab2Masse= 0.01
    var stab2HalbeLaenge= 0.05
    var  stab2EffektiveMasse= stab2Masse*(1-(3/4)*cos(stab2Rotation).pow(2))
    var stab2EffektiveKraft=0.0
    var stab2Reibung= 0.0


    val streckenGrenze = 2.4
    val drehGrenze = 0.62831853
    val kraft = 10.0

    var reibungscoeffizient= 0.0




    var vergroesserungsFaktor = 400
    var hoeheStab=vergroesserungsFaktor*stabHalbeLaenge
    var breiteStab=hoeheStab/20
    var hoeheWagen=hoeheStab/10
    var breiteWagen= hoeheStab/5

    var zeitText = stage.text("$zeit s")
    zeitText.y=600.0
    zeitText.x= 500.0
    zeitText.fontSize=30.0
    var generationText= stage.text("Generation $generation")
    generationText.y= 650.0
    generationText.x= 500.0
    generationText.fontSize=30.0
    var genomText= stage.text("Genom $genom")
    genomText.y= 700.0
    genomText.x= 500.0
    genomText.fontSize=30.0
    //stage.addChild(generationText)

    var cart = stage.solidRect(breiteWagen, hoeheWagen).apply {
        position(250, 1000)
        rotation(Angle(0.0))
        color=Colors.RED
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.00,fixedRotation = true)

    }
    var pole= stage.solidRect(breiteStab, -hoeheStab).apply {
        position(250, 1000)
        rotation(Angle(0.0) )
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.01)
        color=Colors.BLUE
    }
    var pole2= stage.solidRect(breiteStab, -hoeheStab/10).apply {
        position(240, 1000)
        rotation(Angle(0.0) )
        registerBodyWithFixture(type = BodyType.STATIC,friction = 0.01)
        color=Colors.GREENYELLOW
    }


    var aBewegungen=0
    while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && stab2Rotation<drehGrenze && stab2Rotation>-drehGrenze&& aBewegungen<500000){

        delay(TimeSpan(10.0))

        if(stage.keys.justReleased(Key.A)){stabRotation+= 0.05}
        if(stage.keys.justReleased(Key.S)){stabRotation-= 0.05}
        var angewendeteKraft:Double
        var output= netz.rechnen(doubleArrayOf(wagenX,wagenV,stabRotation,stabWinkelgeschwindigkeit,stab2Rotation,stab2Winkelgeschwindigkeit))

        if (output[0]<output[1])  angewendeteKraft= kraft
        else                      angewendeteKraft= -kraft


        stabWinkelbeschleunigung= -(3/(4*stabHalbeLaenge))*(wagenA* cos(stabRotation)+ g* sin(stabRotation)+(stabReibung*stabWinkelgeschwindigkeit)/stabMasse*stabHalbeLaenge)

        stab2Winkelbeschleunigung= -(3/(4*stab2HalbeLaenge))*(wagenA* cos(stab2Rotation)+ g* sin(stab2Rotation)+(stab2Reibung*stab2Winkelgeschwindigkeit)/stab2Masse*stab2HalbeLaenge)

        wagenA= (angewendeteKraft-reibungscoeffizient*sign(wagenV)+((stabEffektiveKraft+stab2EffektiveKraft))/(wagenMasse+(stab2EffektiveMasse+stabEffektiveMasse)))

        stabEffektiveKraft= stabMasse*stabHalbeLaenge*stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation)+ (3/4)*stabMasse*cos(stabRotation)*((stabReibung*stabWinkelgeschwindigkeit)/(stabMasse*stabHalbeLaenge)+g*sin(stabRotation))

        stab2EffektiveKraft= stab2Masse*stab2HalbeLaenge*stab2Winkelgeschwindigkeit.pow(2)*sin(stab2Rotation)+ (3/4)*stab2Masse*cos(stab2Rotation)*((stab2Reibung*stab2Winkelgeschwindigkeit)/(stab2Masse*stab2HalbeLaenge)+g*sin(stab2Rotation))

        stabEffektiveMasse= stabMasse*(1-(3/4)*cos(stabRotation).pow(2))
        stab2EffektiveMasse= stab2Masse*(1-(3/4)*cos(stab2Rotation).pow(2))

        wagenX += zeitschritt*wagenV
        wagenV += zeitschritt*wagenA

        stabRotation+= zeitschritt*stabWinkelgeschwindigkeit
        stabWinkelgeschwindigkeit += zeitschritt*stabWinkelbeschleunigung

        stab2Rotation+= zeitschritt*stab2Winkelgeschwindigkeit
        stab2Winkelgeschwindigkeit += zeitschritt*stab2Winkelbeschleunigung

        aBewegungen++
        zeit+= zeitschritt



        pole.rotation=Angle(stabRotation)
        pole.x=vergroesserungsFaktor*(wagenX+2.4)
        pole2.rotation=Angle(stab2Rotation)
        pole2.x=vergroesserungsFaktor*(wagenX+2.4)-10
        cart.x=vergroesserungsFaktor*(wagenX+2.4)-0.5*breiteWagen




        zeitText.text="$zeit s"
        // generationText.text= generation.toString()

    }
    netz.fitness= aBewegungen.toDouble()
//println(netz.fitness)








}


