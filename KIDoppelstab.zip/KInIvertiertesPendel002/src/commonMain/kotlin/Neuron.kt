class Neuron (var synapsen: DoubleArray, var wert : Double, var bias : Double)
