import kotlin.math.*

fun fitnessFunktion(netz : Netzwerk):Double {

    var zeit = 0.0
    val zeitschritt= 0.01
    val g= 9.81
    var wagenX =0.0
    var wagenV =0.0
    var wagenA= 0.0
    val wagenMasse= 1

    var stabRotation= 0.0174532925199433
    var stabWinkelgeschwindigkeit=0.0
    var stabWinkelbeschleunigung = 0.0
    val stabMasse= 0.1
    var stabHalbeLaenge= 0.5



    val streckenGrenze = 2.4
    val drehGrenze = 0.62831853
    val kraft = 10.0




    var aBewegungen=0
    while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && aBewegungen<5000){

        var angewendeteKraft:Double
        var output= netz.rechnen(doubleArrayOf(wagenX,wagenV,stabRotation,stabWinkelgeschwindigkeit))

        if (output[0]<output[1])  angewendeteKraft= kraft
        else                      angewendeteKraft= -kraft

        stabWinkelbeschleunigung= ((g* sin(stabRotation)+ cos(stabRotation)*((-angewendeteKraft-stabMasse*stabHalbeLaenge*stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation))/(wagenMasse+stabMasse) ))/(stabHalbeLaenge*((4/3)-(stabMasse*cos(stabRotation).pow(2))/(wagenMasse+stabMasse))))
        wagenA= ((angewendeteKraft+stabMasse*stabHalbeLaenge*((stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation))-(stabWinkelbeschleunigung*cos(stabRotation))))/(wagenMasse+stabMasse))
        wagenX += zeitschritt*wagenV
        wagenV += zeitschritt*wagenA

        stabRotation+= zeitschritt*stabWinkelgeschwindigkeit
        stabWinkelgeschwindigkeit += zeitschritt*stabWinkelbeschleunigung

        aBewegungen++
        zeit+= zeitschritt


    }
netz.fitness= aBewegungen.toDouble()
   return aBewegungen.toDouble()

 }



