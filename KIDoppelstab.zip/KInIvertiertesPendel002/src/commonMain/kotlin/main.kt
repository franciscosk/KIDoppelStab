

import kotlin.math.*
 suspend fun main() {
	/** Population erstellen:
	 * Netwerk-Arraygröße = Anzahl der Netzwerke in einer Population
	 * das IntArray ist für die Netztopologie zuständing:
	 * jeder zahl representiert eine Schicht, ihr Wert die Anzahl der Neuronen der schicht
	 * die erste zahl (links) steht für die Inputschicht, die letzte (rechts) für die Outputschicht
	 **/
	var population = Array<Netzwerk>(100) { Netzwerk(arrayOf(6, 5, 2)) }

	 var sel=0.1
	 var mut=200.0
	 var evolutionsschritte = 10
	 var verbessertePopulation=evolutionSchritte(evolutionsschritte, population,mut,100,sel)
println("fertig")
	for(i in verbessertePopulation){
		fitnessFunktion2(i)

	}
	verbessertePopulation.sortByDescending { it.fitness }

	 fitness2Visuell(verbessertePopulation[80])
	//bestenSpeichern(population)
	//optimierung()
	// optimierungSelektionfaktor()
}

/**fun bestenSpeichern(population: Array<Netzwerk>){
/** ein Weg die netwerke abzuspeichern:**/
population.sortByDescending { it.fitness }
		var a = population[0].toString()
		var file = File("Netzwerk$a.txt")
		file.printWriter().use { out ->

			for (aaa in a.indices) {
				out.println(a[aaa])
			}
		}}**/


fun evolutionSchritte( schritte:Int, startPopulation: Array<Netzwerk>,mutationsRate:Double= 100.00, populationsGroesse: Int= 100,selektionsfaktor: Double):Array<Netzwerk>{
	var population= startPopulation
	for ( i in 0 until schritte){

		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate,selektionsfaktor)
		population= neuepopulation
	}
	return population
}
suspend fun evolutionSchritteVisuell(schritte:Int, startPopulation: Array<Netzwerk>, mutationsRate:Double= 100.00, populationsGroesse: Int= 100, selektionsfaktor: Double):Array<Netzwerk>{
	var generation= 1
	var population= startPopulation
	for ( i in 0 until schritte){

		//var neuepopulation =  evolutionVisuell(population,populationsGroesse,mutationsRate,selektionsfaktor,generation)
		//population= neuepopulation
		generation++
	}
	return population
}
fun evolutionSchrittePro( schritte:Int, startPopulation: Array<Netzwerk>,mutationsRate:Double= 100.00, populationsGroesse: Int= 100, selektionsfaktor: Double): Double {
	var population= startPopulation
	for ( i in 0 .. schritte){

		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate,selektionsfaktor)
		population= neuepopulation


	}
	for(i in population){
		fitnessFunktion(i)

	}
	 population.sortByDescending { it.fitness }
	//println(population[0].fitness)
	return (population[0].fitness)
}
fun evolutionAbbruchkriterium(fitness:Double, startPopulation: Array<Netzwerk>,mutationsRate:Double= 100.00, populationsGroesse: Int= 100){
	var population= startPopulation
	var bestfitness= 0.0
	while(fitness>bestfitness){

		var neuepopulation =  evolution(population,populationsGroesse,mutationsRate)
		population= neuepopulation
		population.sortByDescending { it.fitness }
		bestfitness= population[0].fitness
	}
}

fun optimierung() {
	var mutationsrate = 0.1
	var populationsGroesse = 10
	var popArray = arrayOf(5,10,20)
	var mutArray = arrayOf (0.0,1.0,10.0,20.0,50.0,100.0,200.0,500.0)
	var selArray = arrayOf(1,2,5,8,10)
	var selektionsFaktor = 0.1
		for(j in popArray){
			populationsGroesse=10*j
			//println("populationsgröße: $populationsGroesse")
			for(schichtAnzahl in 1..5){
				//println("schichten : $schichtAnzahl")
			for (neuronenanzahl in 2..5){
				//println("neuronen: $neuronenanzahl")
			for(a in selArray){
				selektionsFaktor= 0.1*a
				//println("selektionfaktor: $selektionsFaktor")
				for( i in mutArray){
					mutationsrate= i
					var arr = Array<Int>(schichtAnzahl+2){4}
					for (b in 1..schichtAnzahl){arr[b]=neuronenanzahl}
					arr[schichtAnzahl+1]=2

	var population = Array<Netzwerk>(populationsGroesse) { Netzwerk(arr)}
		var fitness = 0.0
		repeat(30) {
			fitness += evolutionSchrittePro(5, population,mutationsrate,populationsGroesse,selektionsFaktor)
		}
	var avgFitness= fitness/30
println(punktZuKomma(avgFitness))

					//println("$populationsGroesse $schichtAnzahl $neuronenanzahl $selektionsFaktor $mutationsrate $avgFitness")


	}}}}}
	println("fertig")
}
fun optimierungSelektionfaktor() {
	var mutationsrate = 500.0
	var populationsGroesse = 200

	var selArray = arrayOf(1,2,5,8,10,20,50,80,100)
	var selektionsFaktor = 0.1

	for(a in selArray){
		selektionsFaktor= 0.01*a
		//println("populationsgröße: $populationsGroesse")
		for(schichtAnzahl in 1..5){
			//println("schichten : $schichtAnzahl")
			for (neuronenanzahl in 2..5){
				//println("neuronen: $neuronenanzahl")


						var arr = Array<Int>(schichtAnzahl+2){4}
						for (b in 1..schichtAnzahl){arr[b]=neuronenanzahl}
						arr[schichtAnzahl+1]=2

						var population = Array<Netzwerk>(populationsGroesse) { Netzwerk(arr)}
						var fitness = 0.0
						repeat(30) {
							fitness += evolutionSchrittePro(5, population,mutationsrate,populationsGroesse,selektionsFaktor)
						}
						var avgFitness= fitness/30
						println(punktZuKomma(avgFitness))

						//println("$populationsGroesse $schichtAnzahl $neuronenanzahl $selektionsFaktor $mutationsrate $avgFitness")


					}}}
	println("fertig")
}
fun optimierungSchichten() {
	var mutationsrate = 500.0
	var populationsGroesse = 200

	var selArray = arrayOf(1,2,5,8,10,20,50,80,100)
	var selektionsFaktor = 0.1

	for(a in selArray){
		selektionsFaktor= 0.01*a
		//println("populationsgröße: $populationsGroesse")
		for(schichtAnzahl in 1..5){
			//println("schichten : $schichtAnzahl")
			for (neuronenanzahl in 2..5){
				//println("neuronen: $neuronenanzahl")


				var arr = Array<Int>(schichtAnzahl+2){4}
				for (b in 1..schichtAnzahl){arr[b]=neuronenanzahl}
				arr[schichtAnzahl+1]=2

				var population = Array<Netzwerk>(populationsGroesse) { Netzwerk(arr)}
				var fitness = 0.0
				repeat(30) {
					fitness += evolutionSchrittePro(5, population,mutationsrate,populationsGroesse,selektionsFaktor)
				}
				var avgFitness= fitness/30
				println(punktZuKomma(avgFitness))

				//println("$populationsGroesse $schichtAnzahl $neuronenanzahl $selektionsFaktor $mutationsrate $avgFitness")


			}}}
	println("fertig")
}
fun punktZuKomma(i:Double):String{
	var string = i.toString()
	var ruString:String=""
	for (a in string.indices){
		if (string[a]=='.') {
			 ruString+=','}
		else ruString+= string[a]
	}
	return ruString
}

fun evoOpt(){

}
